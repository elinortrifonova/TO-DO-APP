import { useState } from "react";
import "./App.css";

function App() {
  const initialTodos = [
    { id: 1, userId: 1, title: "Buy groceries", completed: false },
    { id: 2, userId: 2, title: "Study React", completed: false },
    { id: 3, userId: 1, title: "Clean room", completed: true },
    { id: 4, userId: 3, title: "Write homework", completed: false },
    { id: 5, userId: 2, title: "Read a book", completed: true },
    { id: 6, userId: 1, title: "Go to the gym", completed: false },
    { id: 7, userId: 3, title: "Prepare dinner", completed: false },
    { id: 8, userId: 2, title: "Call a friend", completed: true },
  ];

  const [todos, setTodos] = useState(initialTodos);

  const [selectedUser, setSelectedUser] = useState("all");

  const [sortOrder, setSortOrder] = useState("asc");

  const filteredTodos = todos.filter((todo) => {
    if (selectedUser === "all") {
      return true;
    }

    return todo.userId === Number(selectedUser);
  });

  const uncompletedTodos = filteredTodos
    .filter((todo) => !todo.completed)
    .sort((a, b) => {
      if (sortOrder === "asc") {
        return a.title.localeCompare(b.title);
      }

      return b.title.localeCompare(a.title);
    });

  const completedTodos = filteredTodos.filter((todo) => todo.completed);

  const completeTodo = (id) => {
    const updatedTodos = todos.map((todo) => {
      if (todo.id === id) {
        return {
          ...todo,
          completed: true,
        };
      }

      return todo;
    });

    setTodos(updatedTodos);
  };

  const uncompleteTodo = (id) => {
    const updatedTodos = todos.map((todo) => {
      if (todo.id === id) {
        return {
          ...todo,
          completed: false,
        };
      }

      return todo;
    });

    setTodos(updatedTodos);
  };

  return (
    <div className="app">
      <h1>Todo App</h1>

      <div className="controls">
        <div>
          <label>Filter by User:</label>
          <select
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
          >
            <option value="all">All Users</option>
            <option value="1">User 1</option>
            <option value="2">User 2</option>
            <option value="3">User 3</option>
          </select>
        </div>

        <div>
          <label>Sort Uncompleted:</label>
          <select
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value)}
          >
            <option value="asc">A-Z</option>
            <option value="desc">Z-A</option>
          </select>
        </div>
      </div>

      <div className="todo-sections">
        <div className="section">
          <h2>Uncompleted Todos</h2>

          {uncompletedTodos.length === 0 ? (
            <p>No uncompleted todos.</p>
          ) : (
            <ul>
              {uncompletedTodos.map((todo) => (
                <li key={todo.id} className="todo-item">
                  <div>
                    <strong>{todo.title}</strong>
                    <p>User ID: {todo.userId}</p>
                  </div>

                  <button className ="complete-button" onClick={() => completeTodo(todo.id)}>
                    Complete
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="section">
          <h2>Completed Todos</h2>

          {completedTodos.length === 0 ? (
            <p>No completed todos.</p>
          ) : (
            <ul>
              {completedTodos.map((todo) => (
                <li key={todo.id} className="todo-item completed">
                  <div>
                    <strong>{todo.title}</strong>
                    <p>User ID: {todo.userId}</p>
                  </div>

                  <button className ="uncomplete-button" onClick={() => uncompleteTodo(todo.id)}>
                    Undo
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;